# a=input()         #in this input wecan give any kind of input types
# print(a,type(a))
 
# name=input("enter your name:")      #in this input wecan give any kind of input types
# print(name,type(name))  

# age=int(input("enter your age:"))     # here we can give only int input values
# print(age,type(age))

# weight=float(input("enter your weight"))   #input values are in float only


'''input type (types)'''

name=input("enter your name:")      #printing all details at a time.
age=int(input("enter your age:"))
weight=float(input("enter your weight:"))
print(name,age,weight)

print("your name is:{},and age is:{},weight is:{}".format(name,age,weight))    #giving i/p values by format 
print("your name is:%s_and age is:%d+weight is:%f"%(name,age,weight))            #giving i/p values by format specifier 
print("your name is:{0},and age is:{1},weight is{2}")                     #giving i/p values by positions
print("your name is:{name}and age is:{age}weight is:{weight}")          #giving i/p values by set type