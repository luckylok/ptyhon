from fractions import Fraction as f
from re import A
# a=f(2,1)
# b=f(7,2)
# # a=f(0,5)   #zero division error 
# c=f(5,3)
# print(a,type(a))
# print(b,type(b))
# print(c,type(c))

'''underscore(_)'''
a=2_34   #after giving underscore we cannot add any kind of special characters
print(a)
b=2_3.4
print(b)
c=2_34.
print(c)
