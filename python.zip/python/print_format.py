# to print hello "world in python

# print('hello "world')
# print("""hello "world""")
# print('''hello "world''')

# # to print    print("iam learning")
# print('print("iam learning")')
# print('''print("iam learning")''')
# print("""print("iam learning")""")
# print("print" '("iam learning")')
# print("hello sir today iam not able to vome to the inistuite")

'''end property'''

# print("Hi loknath!!",end=" ")  #in end method after each print statement  will add to given next line statement
# print("How are u?")
# print("Hi loknath!!",end="_.")
# print("How are u?")
# print("Hi loknath!!",end="-..")
# print("How are u?")

'''separate property'''
# print("loknath",24,sep=":")  #in this method the words separated with special charaters
# print("loknath",24,sep="___")
# print("loknath",24,sep="==")

'''combination of edge and separate'''
# print("core","pthon",end="" "hello") #corehello python
# print("core","pthon",end=""  "hello\n") #core--hellopython
print("core""pthon",end=""  "hello") #
print("core","pthon",end="" "hai")

print("core","pthon",sep="-",end="hai\n")
print("core","pthon",sep=".",end="hello")
print("core","pthon",sep=" ",end="bye")
