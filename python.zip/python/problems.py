# a=0.1+0.2
# print(a)



# p=0.1+0.2
# print("%.1f"%p)


from decimal import decimal as d
print(d(0.1)+d(0.2))
