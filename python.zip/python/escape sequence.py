# #\n for the nwe line
# print("hello\nworld")    
# print('hello\nworld')
# print("""hello\nworld""")
# print('''hello\nworld''')

# # \t is giving 1 to 8 spaces in between sentences &it will use in terminals of python

# print('hi\tall')
# print("hi\t all")
# print('\thi all')

# \b is used to remove the before word 
print('we know the pro\bcess')
print('''we know\bthe process''')
print("""we knowt\bhe process""")
# \s is to shudown the system 
# \r is to restart the system

# import os
# os. system('shutdown /r /t 0')