a=5
_b=10
_c_=15
d1=20
e_=25
print(a)
print(_b)
print(_c_)
print(d1)
print(e_)

# # variables does not allow to execute
# 1=5  
# 1a=10
# @=20
# .q=30

a=10
b=20
print(a),print(b)
print(a);print(b)
print(a,b)