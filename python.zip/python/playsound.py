

# # shutdown the system with this code
# import os
# os.system('shutdown /s /t 1')      



# playsound
from playsound import playsound
playsound('E:\\python\\wake.mp3')