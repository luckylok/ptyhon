'''binary number'''
# a=bin(10)         # when we converting a nuber to binary it will be str
# print(a,type(a))

# b=0B1010           # when we converting a binary number to number it will be int
# print(b,type(b))
# c=0b1010
# print(c,type(c))

'''hexa decimal'''
# d=hex(50)
# print(d,type(d)) 

# e=0x32
# print(e,type(e))

'''octal decimal'''
# d=oct(50)
# print(d,type(d))
# d=0o62
# print(d,type(d))
