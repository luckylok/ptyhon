''' int type'''
# a=50;b=80;c=-56
# print(a,type(a))
# print(a,type(b))
# print(a,type(c))
# print(float(c))       # conversion i ti f -56.0

# print(a,b,c,type(c))  # 50 80 -56 class int

'''float '''

# d=55.650
# print(d,type(d))    # 55.650 class float
# print(int(d))       # conversion f to i 55

# p=0.1+0.2
# print(p)
# print('%f'%p)      # 1f=6 Zeros
# print('%.1f'%p)    # After .how many values we insert that only in output

'''strings'''

# a='hello all'
# b="hello all"
# c='''hello all'''
# d="""hello all"""
# d='hello' " "'all'
# e="hello" ' ' "all"
# f="""hello""" ' '"""all"""
# g='''hello''' " " '''all'''
# print(a,type(a))
# print(b)
# print(c)
# print(d)
# print(a,b,c,d)
# print(e)
# print(f)
# print(g)

'''giving name to string'''
# name="loknath" 
# number='LE-509'
# name1=9705801055
# print("My name is:"+name) 
# print("My rollnumber is:"+number) 
# print("My cell number:"+name1)       # type error: in str type int cannot concatenate with +
#  print("My cell number:",name1)      #in str , willl oncatinate direecttt with any data type
# print("My name is:"+" "+name)          # in the str we can add space also " " ' ' 

'''format specifier'''
# year=2021
# print("%d"%year)  #decimal
# print("%f"%year)  #float
# print("%s"%year)  #string
# print("%c"%year)  #char
# print(year)

'''None '''

# b=None
# print(b,type(b))   #None is nothing

'''boolean'''
# a=5<4             # this boolean used for true false statements only
# b=5>4
# c=50.66>51.60
# print(a,type(a))
# print(b,type(b))
# print(c,type(c))

'''char'''
# l="Hello Everyone"
# print("%c"%l[0])    #H 
# print("%c"%l[7])    #v
# print("%c"%l[8])    #e
# print("%c"%l[11])   #o
# print("%c"%l[-1])   #e

'''list'''  
#it indicate with[]

# t=["pondhara","loknath",24,6.58]
# print(t,type(t))
# print("my first is:"+t[0])
# print("my last is:"+t[1])
# print("my age is:",t[2])
# print(t[0]+t[1])
# print("my weight is:",t[3])

'''modifications in list'''

# t[0]= 'world'
# t[1]= 9999
# t[3]= 0.11111111

# print(t)


'''tuple'''
# x=('apple','assus','dell','samsung')     #in tuple it will print same as what we given with [,] also
# print(x)

'''sets  '''
# j={22,56.55,"ptyhon",("program,1986")}
# print(j,type(j))     #in sets it wont accept empty{}set 
# print(j(3))      #in sets is not callable function

'''frozen set'''
# f={5,22.5,55}
# print(f,type(f))
# h=frozenset(f)
# print(h,type(h))

'''dictionary'''
#it is a pair key value data type it have two sides {left side:right side}this is format of dict
# camera={
# 1:"sony",
# 2:"cannon",
# 3:'nikon'}
# print(camera[2])

# s={1:"", 2:7, 3:"python", 4:92.58, 5:[2,5], 6:(22,55), 7:{22,36}, 8:{6:"loknath"}}
# print(s[1],type(s[1]))  # dict using  empty str
# print(s[2],type(s[2]))  #dict using  int
# print(s[3],type(s[3]))  #dict using  str value
# print(s[4],type(s[4]))  #dict using  float
# print(s[5],type(s[5]))  #dict using  list
# print(s[6],type(s[6]))  #dict using  tuple
# print(s[7],type(s[7]))  #dict using  set
# print(s[8],type(s[8]))  #dict using  dict value

'''dict types'''
# print(s.keys())    #it prints the all keys in a dict
# print(s.values())  #it prints the values of dict
# print(s.items())   #it print totsl iteams in the dict

'''range'''
# r=range(6)    # this range will give squares and range of the letter or given data
# # print(r,type(r))
# # for i in r:print(i)   #0,1,2,3,4,5,6,7
# # for k in r:print(k*2)    # 0,2,4,6,8,10
# for k in r:print(k**3)   #0 ,1,8,27,64

'''byte'''
#when we write byte data type then use before b
# z=b"loknath"
# print(z,type(z))    #b'loknath'
# d=bytearray(b"hey loknath")   #bytearray(b'hey loknath')
# print(d)

'''complex'''
# in python for complex we use(a+jb)format
# a=complex(2+2j) 
# print(a,type(a))      
# b=complex(2j) 
# print(b)   
# c=complex(2)
# print(c)
# d=complex(0+2j)
# print(d)
# e=complex(2+0j)
# print(e)
# f=complex(0+0j)
# print(f)
# g=complex(2+(-0j))
# print(g)
# h=complex(-2+2j)
# print(h)
# i=complex(-2+0j)
# print(i)
# j=complex(2-2j)
# print(j)
# k=complex(2+2j)
# print(k)
# l=complex(-0+0j)
# print(l)
# l=complex(-0-0j)
# print(l)
# l=complex(-0-(0j))
# print(l)
